package com.example.mousemc;

import android.content.Context;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.ByteArrayOutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** Простой журнал: пишет события и ошибки в файл, чтобы их можно было прислать. */
public final class Report {
    private Report() {}

    private static File file(Context c) {
        return new File(c.getFilesDir(), "report.txt");
    }

    public static synchronized void log(Context c, String msg) {
        try {
            File f = file(c);
            if (f.length() > 24000) {
                String old = read(c);
                old = old.substring(Math.max(0, old.length() - 12000));
                FileWriter w0 = new FileWriter(f, false);
                w0.write(old);
                w0.close();
            }
            String t = new SimpleDateFormat("HH:mm:ss.SSS", Locale.US).format(new Date());
            FileWriter w = new FileWriter(f, true);
            w.write(t + " " + msg + "\n");
            w.close();
        } catch (Throwable ignored) {}
    }

    public static synchronized String read(Context c) {
        try {
            File f = file(c);
            if (!f.exists()) return "";
            FileInputStream in = new FileInputStream(f);
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[4096];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            in.close();
            return out.toString("UTF-8");
        } catch (Throwable t) {
            return "";
        }
    }

    public static synchronized void clear(Context c) {
        try { file(c).delete(); } catch (Throwable ignored) {}
    }

    public static String stack(Throwable t) {
        StringBuilder sb = new StringBuilder(String.valueOf(t));
        StackTraceElement[] st = t.getStackTrace();
        for (int i = 0; i < st.length && i < 6; i++) sb.append("\n    at ").append(st[i]);
        return sb.toString();
    }
}
