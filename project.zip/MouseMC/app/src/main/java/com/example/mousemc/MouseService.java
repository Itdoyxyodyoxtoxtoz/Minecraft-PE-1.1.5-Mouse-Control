package com.example.mousemc;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.accessibilityservice.GestureDescription.StrokeDescription;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.os.Handler;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.widget.Button;

public class MouseService extends AccessibilityService {

    // ---- Настройки (можно менять) ----
    static final float SENS = 2.5f;      // чувствительность камеры
    static final int TICK = 50;          // длительность одного шага жеста, мс
    static final float CAM_X = 0.72f;    // откуда "тянем" камеру (доля ширины)
    static final float CAM_Y = 0.35f;    // откуда "тянем" камеру (доля высоты)

    private WindowManager wm;
    private CaptureView cap;
    private Button btn;
    private WindowManager.LayoutParams capLp;
    private final Handler h = new Handler(Looper.getMainLooper());

    private boolean on = false;
    private boolean busy = false;
    private boolean left = false, right = false, pendingTap = false;
    private float accX = 0, accY = 0;
    private StrokeDescription hold = null;

    private class CaptureView extends View {
        CaptureView(Context c) {
            super(c);
            setFocusable(true);
            setFocusableInTouchMode(true);
            setOnCapturedPointerListener(new View.OnCapturedPointerListener() {
                @Override public boolean onCapturedPointer(View v, MotionEvent e) {
                    onMouse(e);
                    return true;
                }
            });
        }
        @Override public void onWindowFocusChanged(boolean hasFocus) {
            super.onWindowFocusChanged(hasFocus);
            if (hasFocus && on) requestPointerCapture();
        }
    }

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);

        cap = new CaptureView(this);
        capLp = new WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                | WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT);
        wm.addView(cap, capLp);

        btn = new Button(this);
        btn.setText("МЫШЬ: ВЫКЛ");
        btn.setTextSize(11);
        btn.setAllCaps(false);
        btn.setTextColor(Color.WHITE);
        btn.setBackgroundColor(0x99000000);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { setOn(!on); }
        });
        WindowManager.LayoutParams bl = new WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT);
        bl.gravity = Gravity.TOP | Gravity.END;
        wm.addView(btn, bl);
    }

    private void setOn(boolean v) {
        on = v;
        btn.setText(on ? "МЫШЬ: ВКЛ" : "МЫШЬ: ВЫКЛ");
        if (on) {
            capLp.flags &= ~(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                    | WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE);
            wm.updateViewLayout(cap, capLp);
            cap.requestFocus();
            cap.requestPointerCapture();
            h.postDelayed(new Runnable() {
                @Override public void run() { if (on) cap.requestPointerCapture(); }
            }, 300);
        } else {
            cap.releasePointerCapture();
            capLp.flags |= WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                    | WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
            wm.updateViewLayout(cap, capLp);
            left = false; right = false; pendingTap = false;
            accX = 0; accY = 0;
            tick();   // отпустить зажатый "палец", если он был
        }
    }

    private void onMouse(MotionEvent e) {
        accX += e.getX() * SENS;
        accY += e.getY() * SENS;

        int bs = e.getButtonState();
        boolean l = (bs & MotionEvent.BUTTON_PRIMARY) != 0;
        boolean r = (bs & MotionEvent.BUTTON_SECONDARY) != 0;
        if (r && !right) pendingTap = true;
        left = l;
        right = r;

        if (!busy) tick();
    }

    private static int clamp(int v, int lim) {
        return Math.max(-lim, Math.min(lim, v));
    }

    private void tick() {
        int dx = (int) accX, dy = (int) accY;
        accX -= dx; accY -= dy;

        boolean needHold = (on && left) || hold != null;
        if (dx == 0 && dy == 0 && !needHold && !pendingTap) return;
        if (!on && hold == null) return;

        DisplayMetrics m = getResources().getDisplayMetrics();
        float cx = m.widthPixels / 2f, cy = m.heightPixels / 2f;
        GestureDescription.Builder b = new GestureDescription.Builder();
        int n = 0;

        // Камера: короткий свайп от точки-якоря
        if (on && (dx != 0 || dy != 0)) {
            int lim = (int) (m.widthPixels * 0.2f);
            dx = clamp(dx, lim);
            dy = clamp(dy, lim);
            float ax = m.widthPixels * CAM_X, ay = m.heightPixels * CAM_Y;
            Path p = new Path();
            p.moveTo(ax, ay);
            p.lineTo(ax + dx, ay + dy);
            b.addStroke(new StrokeDescription(p, 0, TICK));
            n++;
        }

        // Левая кнопка: "палец" держится в центре экрана
        if (on && left) {
            Path p = new Path();
            p.moveTo(cx, cy);
            hold = (hold == null)
                ? new StrokeDescription(p, 0, TICK, true)
                : hold.continueStroke(p, 0, TICK, true);
            b.addStroke(hold);
            n++;
        } else if (hold != null) {
            Path p = new Path();
            p.moveTo(cx, cy);
            StrokeDescription end = hold.continueStroke(p, 0, TICK, false);
            hold = null;
            b.addStroke(end);
            n++;
        }

        // Правая кнопка: короткое касание в центре
        if (pendingTap) {
            pendingTap = false;
            if (on && !left) {
                Path p = new Path();
                p.moveTo(cx, cy);
                b.addStroke(new StrokeDescription(p, 0, 60));
                n++;
            }
        }

        if (n == 0) return;
        busy = true;
        boolean ok = dispatchGesture(b.build(), new GestureResultCallback() {
            @Override public void onCompleted(GestureDescription g) {
                busy = false;
                tick();
            }
            @Override public void onCancelled(GestureDescription g) {
                busy = false;
                hold = null;
            }
        }, null);
        if (!ok) { busy = false; hold = null; }
    }

    @Override
    protected boolean onKeyEvent(KeyEvent e) {
        if (e.getKeyCode() == KeyEvent.KEYCODE_F8 && e.getAction() == KeyEvent.ACTION_DOWN) {
            setOn(!on);
            return true;
        }
        return false;
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) {}
    @Override public void onInterrupt() {}

    @Override
    public void onDestroy() {
        super.onDestroy();
        try { if (cap != null) wm.removeView(cap); } catch (Exception ignored) {}
        try { if (btn != null) wm.removeView(btn); } catch (Exception ignored) {}
    }
}
