package com.example.mousemc;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.accessibilityservice.GestureDescription.StrokeDescription;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class MouseService extends AccessibilityService {

    // ---- Настройки (можно менять) ----
    static final float SENS = 2.5f;      // чувствительность камеры
    static final int TICK = 50;          // длительность шага жеста, мс
    static final float CAM_X = 0.72f;    // откуда "тянем" камеру (доля ширины)
    static final float CAM_Y = 0.45f;    // откуда "тянем" камеру (доля высоты)

    // Положение экранных кнопок игры (доли ширины и высоты экрана)
    static final float[] P_W     = {0.140f, 0.710f};  // вперёд
    static final float[] P_A     = {0.087f, 0.826f};  // влево
    static final float[] P_S     = {0.140f, 0.944f};  // назад
    static final float[] P_D     = {0.192f, 0.826f};  // вправо
    static final float[] P_SNEAK = {0.140f, 0.826f};  // присесть (центр крестовины)
    static final float[] P_JUMP  = {0.937f, 0.806f};  // прыжок
    static final float[] P_INV   = {0.692f, 0.951f};  // инвентарь (кнопка "...")
    static final float[] P_CENTER = {0.500f, 0.500f}; // центр экрана
    static final float HOTBAR_Y = 0.951f;
    static final float[] HOTBAR_X = {0.359f, 0.397f, 0.434f, 0.471f, 0.509f,
                                     0.546f, 0.582f, 0.620f, 0.658f};

    private static final int ID_LEFT = -1;   // левая кнопка мыши

    private WindowManager wm;
    private CaptureView cap;
    private Button btn;
    private TextView hud;
    private int evCount = 0, gOk = 0, gCancel = 0, gFail = 0, lastDx = 0, lastDy = 0;
    private String lastErr = "";
    private long lastHud = 0;
    private WindowManager.LayoutParams capLp;
    private final Handler h = new Handler(Looper.getMainLooper());

    private boolean on = false;
    private boolean captured = false;
    private boolean busy = false;
    private boolean left = false, right = false;
    private float accX = 0, accY = 0;
    private int slot = 0;
    private long lastDispatch = 0;
    private int cancels = 0;

    private final Map<Integer, StrokeDescription> holds = new HashMap<>();
    private final Set<Integer> keysDown = new HashSet<>();
    private final ArrayList<float[]> taps = new ArrayList<>();

    private class CaptureView extends View {
        CaptureView(Context c) {
            super(c);
            setFocusable(true);
            setFocusableInTouchMode(true);
            setOnCapturedPointerListener(new View.OnCapturedPointerListener() {
                @Override public boolean onCapturedPointer(View v, MotionEvent e) {
                    onMouse(e);
                    return true;
                }
            });
        }
        @Override public void onWindowFocusChanged(boolean hasFocus) {
            super.onWindowFocusChanged(hasFocus);
            if (hasFocus && on) requestPointerCapture();
        }
        @Override public void onPointerCaptureChange(boolean hasCapture) {
            super.onPointerCaptureChange(hasCapture);
            captured = hasCapture;
            log("захват мыши = " + hasCapture);
            updateLabel();
        }
    }

    private void log(String m) { Report.log(this, m); }

    private void updateHud(boolean force) {
        if (hud == null) return;
        long now = android.os.SystemClock.uptimeMillis();
        if (!force && now - lastHud < 150) return;
        lastHud = now;
        hud.setText("захват: " + captured + "  вкл: " + on
            + "\nсобытий мыши: " + evCount + "  dx/dy: " + lastDx + "/" + lastDy
            + "\nЛКМ: " + left + "  ПКМ: " + right
            + "\nудержаний: " + holds.size() + "  клавиш: " + keysDown.size()
            + "\nжесты ок/отмена/сбой: " + gOk + "/" + gCancel + "/" + gFail
            + (lastErr.isEmpty() ? "" : "\n" + lastErr));
    }

    private void updateLabel() {
        if (btn == null) return;
        if (!on) { btn.setText("МЫШЬ: ВЫКЛ"); return; }
        btn.setText("ВКЛ " + (captured ? "захват" : "нет захвата")
            + " L" + (left ? 1 : 0) + " K" + keysDown.size()
            + " H" + holds.size() + " c" + cancels);
    }

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);

        cap = new CaptureView(this);
        capLp = new WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                | WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT);
        wm.addView(cap, capLp);

        btn = new Button(this);
        btn.setTextSize(11);
        btn.setAllCaps(false);
        btn.setTextColor(Color.WHITE);
        btn.setBackgroundColor(0x99000000);
        updateLabel();
        btn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { setOn(!on); }
        });
        WindowManager.LayoutParams bl = new WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT);
        bl.gravity = Gravity.TOP | Gravity.END;
        wm.addView(btn, bl);

        // Диагностическая панель (левый верхний угол)
        hud = new TextView(this);
        hud.setTextSize(10);
        hud.setTextColor(Color.WHITE);
        hud.setBackgroundColor(0x88000000);
        WindowManager.LayoutParams hl = new WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT);
        hl.gravity = Gravity.TOP | Gravity.START;
        wm.addView(hud, hl);
        updateHud(true);

        DisplayMetrics dm = getResources().getDisplayMetrics();
        log("служба запущена, экран " + dm.widthPixels + "x" + dm.heightPixels
            + ", " + android.os.Build.MANUFACTURER + " " + android.os.Build.MODEL
            + ", Android " + android.os.Build.VERSION.RELEASE);
        final Thread.UncaughtExceptionHandler prev = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler() {
            @Override public void uncaughtException(Thread th, Throwable ex) {
                Report.log(MouseService.this, "СБОЙ ПРИЛОЖЕНИЯ: " + Report.stack(ex));
                if (prev != null) prev.uncaughtException(th, ex);
            }
        });

        releaseAll();
        h.postDelayed(watchdog, 300);
    }

    private void releaseAll() {
        holds.clear();
        busy = false;
        try {
            Path p = new Path();
            p.moveTo(2, 2);
            GestureDescription.Builder b = new GestureDescription.Builder();
            b.addStroke(new StrokeDescription(p, 0, 10));
            dispatchGesture(b.build(), null, null);
        } catch (Throwable ignored) {}
    }

    private final Runnable watchdog = new Runnable() {
        @Override public void run() {
            try {
                long now = SystemClock.uptimeMillis();
                if (busy && now - lastDispatch > 800) {
                    cancels++;
                    log("сторожевой таймер: жест завис, сбрасываю");
                    releaseAll();
                } else if (!on && !busy && !holds.isEmpty()) {
                    log("сторожевой таймер: остались зажатые пальцы при выключенной мыши, сбрасываю");
                    releaseAll();
                }
                updateLabel();
                updateHud(false);
            } catch (Throwable ignored) {}
            h.postDelayed(this, 300);
        }
    };

    private void setOn(boolean v) {
        try { setOnInner(v); } catch (Throwable t) { emergencyOff(t); }
    }

    private void setOnInner(boolean v) {
        on = v;
        log("мышь " + (on ? "ВКЛ" : "ВЫКЛ"));
        if (on) {
            // Окно получает фокус (нужен для захвата мыши), но касания пальцем проходят в игру
            capLp.flags &= ~WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
            wm.updateViewLayout(cap, capLp);
            cap.requestFocus();
            cap.requestPointerCapture();
            h.postDelayed(new Runnable() {
                @Override public void run() { if (on) cap.requestPointerCapture(); }
            }, 300);
        } else {
            cap.releasePointerCapture();
            capLp.flags |= WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
            wm.updateViewLayout(cap, capLp);
            left = false; right = false;
            keysDown.clear(); taps.clear();
            accX = 0; accY = 0;
            captured = false;
            tick();   // отпустить все зажатые "пальцы"
            if (!holds.isEmpty()) releaseAll();
        }
        updateLabel();
        updateHud(true);
    }

    private void emergencyOff(Throwable t) {
        lastErr = "ОШИБКА: " + t;
        log("ОШИБКА: " + Report.stack(t));
        on = false;
        left = false; right = false;
        keysDown.clear(); taps.clear(); holds.clear();
        accX = 0; accY = 0;
        busy = false;
        captured = false;
        try {
            cap.releasePointerCapture();
            capLp.flags |= WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
            wm.updateViewLayout(cap, capLp);
            btn.setText("МЫШЬ: ВЫКЛ (ошибка)");
        } catch (Throwable ignored) {}
    }

    private void onMouse(MotionEvent e) {
        try { onMouseInner(e); } catch (Throwable t) { emergencyOff(t); }
    }

    private void onMouseInner(MotionEvent e) {
        evCount++;
        if (evCount == 1) log("получено первое событие мыши");
        lastDx = (int) e.getX();
        lastDy = (int) e.getY();
        if (e.getActionMasked() == MotionEvent.ACTION_SCROLL) {
            float v = e.getAxisValue(MotionEvent.AXIS_VSCROLL);
            if (v != 0) {
                slot = (slot + (v < 0 ? 1 : 8)) % 9;
                taps.add(new float[]{HOTBAR_X[slot], HOTBAR_Y});
                tick();
            }
            return;
        }
        accX += e.getX() * SENS;
        accY += e.getY() * SENS;

        int bs = e.getButtonState();
        boolean l = (bs & MotionEvent.BUTTON_PRIMARY) != 0;
        boolean r = (bs & MotionEvent.BUTTON_SECONDARY) != 0;
        if (l != left) log("ЛКМ = " + l);
        if (r != right) log("ПКМ = " + r);
        if (r && !right) taps.add(P_CENTER);
        left = l;
        right = r;
        tick();
        updateHud(false);
    }

    // ---- Клавиатура: WASD, пробел, Shift, 1-9, E ----
    private static float[] holdPos(int id) {
        switch (id) {
            case KeyEvent.KEYCODE_W: return P_W;
            case KeyEvent.KEYCODE_A: return P_A;
            case KeyEvent.KEYCODE_S: return P_S;
            case KeyEvent.KEYCODE_D: return P_D;
            case KeyEvent.KEYCODE_SPACE: return P_JUMP;
            case KeyEvent.KEYCODE_SHIFT_LEFT: return P_SNEAK;
            case ID_LEFT: return P_CENTER;
            default: return null;
        }
    }

    @Override
    protected boolean onKeyEvent(KeyEvent e) {
        try {
            int k = e.getKeyCode();
            boolean down = e.getAction() == KeyEvent.ACTION_DOWN;
            if (k == KeyEvent.KEYCODE_F8) {
                if (down && e.getRepeatCount() == 0) setOn(!on);
                return true;
            }
            if (down && e.getRepeatCount() == 0) log("клавиша " + KeyEvent.keyCodeToString(k) + (on ? "" : " (мышь выкл, пропущена)"));
            if (!on) return false;

            if (holdPos(k) != null) {
                if (down) keysDown.add(k); else keysDown.remove(k);
                tick();
                return true;
            }
            if (k >= KeyEvent.KEYCODE_1 && k <= KeyEvent.KEYCODE_9) {
                if (down && e.getRepeatCount() == 0) {
                    slot = k - KeyEvent.KEYCODE_1;
                    taps.add(new float[]{HOTBAR_X[slot], HOTBAR_Y});
                    tick();
                }
                return true;
            }
            if (k == KeyEvent.KEYCODE_E) {
                if (down && e.getRepeatCount() == 0) { taps.add(P_INV); tick(); }
                return true;
            }
        } catch (Throwable t) {
            emergencyOff(t);
        }
        return false;
    }

    // ---- Жесты ----
    private static int clamp(int v, int lim) {
        return Math.max(-lim, Math.min(lim, v));
    }

    private Path pt(float[] f, DisplayMetrics m) {
        Path p = new Path();
        p.moveTo(Math.max(1f, Math.min(m.widthPixels - 1f, f[0] * m.widthPixels)),
                 Math.max(1f, Math.min(m.heightPixels - 1f, f[1] * m.heightPixels)));
        return p;
    }

    private void tick() {
        if (busy) return;
        try {
            tickInner();
        } catch (Throwable t) {
            emergencyOff(t);
        }
    }

    private void tickInner() {
        int dx = (int) accX, dy = (int) accY;
        if (Math.abs(accX) + Math.abs(accY) < 30f) {
            dx = 0; dy = 0;            // мелкие движения копим, чтобы не было "тапов"
        } else {
            accX -= dx; accY -= dy;
        }

        Set<Integer> desired = new HashSet<>();
        if (on) {
            desired.addAll(keysDown);
            if (left) desired.add(ID_LEFT);
        }
        if (dx == 0 && dy == 0 && desired.isEmpty() && holds.isEmpty() && taps.isEmpty()) return;
        if (!on && holds.isEmpty()) return;

        DisplayMetrics m = getResources().getDisplayMetrics();
        GestureDescription.Builder b = new GestureDescription.Builder();
        int n = 0;

        // Камера: короткий свайп от точки-якоря
        if (on && (dx != 0 || dy != 0)) {
            dx = clamp(dx, (int) (m.widthPixels * 0.15f));
            dy = clamp(dy, (int) (m.heightPixels * 0.2f));
            float ax = m.widthPixels * CAM_X, ay = m.heightPixels * CAM_Y;
            Path p = new Path();
            p.moveTo(ax, ay);
            p.lineTo(Math.max(1f, Math.min(m.widthPixels - 1f, ax + dx)),
                     Math.max(1f, Math.min(m.heightPixels - 1f, ay + dy)));
            b.addStroke(new StrokeDescription(p, 0, TICK));
            n++;
        }

        // Отпустить "пальцы", которые больше не нужны
        ArrayList<Integer> toEnd = new ArrayList<>();
        for (Map.Entry<Integer, StrokeDescription> en : holds.entrySet()) {
            if (!desired.contains(en.getKey())) toEnd.add(en.getKey());
        }
        for (Integer id : toEnd) {
            StrokeDescription end = holds.remove(id)
                .continueStroke(pt(holdPos(id), m), 0, TICK, false);
            b.addStroke(end);
            n++;
        }

        // Держать нужные "пальцы" (ходьба, прыжок, ломание блока)
        for (Integer id : desired) {
            Path p = pt(holdPos(id), m);
            StrokeDescription old = holds.get(id);
            StrokeDescription sd = (old == null)
                ? new StrokeDescription(p, 0, TICK, true)
                : old.continueStroke(p, 0, TICK, true);
            holds.put(id, sd);
            b.addStroke(sd);
            n++;
        }

        // Короткие касания: правая кнопка, хотбар, инвентарь
        int tapCount = 0;
        while (!taps.isEmpty() && tapCount < 3) {
            float[] t = taps.remove(0);
            if (!on) continue;
            if (t == P_CENTER && left) continue;   // центр уже занят зажатием
            b.addStroke(new StrokeDescription(pt(t, m), 0, 60));
            n++;
            tapCount++;
        }

        if (n == 0) return;
        busy = true;
        lastDispatch = SystemClock.uptimeMillis();
        boolean ok = dispatchGesture(b.build(), new GestureResultCallback() {
            @Override public void onCompleted(GestureDescription g) {
                busy = false;
                gOk++;
                tick();
                updateHud(false);
            }
            @Override public void onCancelled(GestureDescription g) {
                busy = false;
                cancels++;
                gCancel++;
                if (gCancel <= 20) log("жест ОТМЕНЁН #" + gCancel + " удержаний=" + holds.size() + " клавиш=" + keysDown.size() + " ЛКМ=" + left);
                holds.clear();
                taps.clear();
                updateHud(false);
            }
        }, null);
        if (!ok) { busy = false; gFail++; if (gFail <= 20) log("жест не принят системой #" + gFail); holds.clear(); updateHud(false); }
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) {}
    @Override public void onInterrupt() {}

    @Override
    public void onDestroy() {
        super.onDestroy();
        try { if (cap != null) wm.removeView(cap); } catch (Exception ignored) {}
        try { if (btn != null) wm.removeView(btn); } catch (Exception ignored) {}
        try { if (hud != null) wm.removeView(hud); } catch (Exception ignored) {}
    }
}
