package com.example.mousemc;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        int p = (int) (16 * getResources().getDisplayMetrics().density);
        box.setPadding(p, p, p, p);

        TextView t = new TextView(this);
        t.setTextSize(16);
        t.setText(
            "MouseMC — мышь для Minecraft PE\n\n"
          + "1. Нажми кнопку ниже и включи MouseMC в «Специальных возможностях» "
          + "(он может быть в разделе «Установленные приложения»).\n"
          + "2. Подключи мышь и запусти игру.\n"
          + "3. Нажми маленькую кнопку «МЫШЬ» в углу экрана (или клавишу F8): "
          + "включится захват мыши.\n\n"
          + "Управление:\n"
          + "• движение мыши — камера\n"
          + "• левая кнопка (держать) — ломать блок\n"
          + "• правая кнопка — поставить блок / использовать\n"
          + "• F8 или кнопка «МЫШЬ» — вкл/выкл (когда выключено, играй пальцем)\n\n"
          + "Если камера слишком быстрая или медленная, скажи мне, и я поменяю чувствительность.");
        box.addView(t);

        Button open = new Button(this);
        open.setText("Открыть настройки спец. возможностей");
        open.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
            }
        });
        box.addView(open);

        ScrollView sv = new ScrollView(this);
        sv.addView(box);
        setContentView(sv);
    }
}
