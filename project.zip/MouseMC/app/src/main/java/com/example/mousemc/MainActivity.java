package com.example.mousemc;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private TextView reportView;

    private String header() {
        return "Устройство: " + Build.MANUFACTURER + " " + Build.MODEL
            + ", Android " + Build.VERSION.RELEASE + " (SDK " + Build.VERSION.SDK_INT + ")\n";
    }

    private String fullReport() {
        String r = Report.read(this);
        if (r.length() > 7000) r = "...\n" + r.substring(r.length() - 7000);
        return header() + (r.isEmpty() ? "(журнал пока пуст)" : r);
    }

    private void refresh() {
        reportView.setText(fullReport());
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        int p = (int) (16 * getResources().getDisplayMetrics().density);
        box.setPadding(p, p, p, p);

        TextView t = new TextView(this);
        t.setTextSize(15);
        t.setText(
            "MouseMC — мышь для Minecraft PE\n\n"
          + "1. Включи MouseMC в «Специальных возможностях».\n"
          + "2. Подключи мышь и запусти игру.\n"
          + "3. Нажми кнопку «МЫШЬ» в углу экрана (или F8).\n\n"
          + "Управление: мышь — камера, левая кнопка (держать) — ломать, правая — поставить, "
          + "WASD — ходьба, пробел — прыжок, Shift — присесть, 1-9 или колесо — предметы, E — инвентарь.\n");
        box.addView(t);

        Button open = new Button(this);
        open.setText("Открыть настройки спец. возможностей");
        open.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
            }
        });
        box.addView(open);

        TextView title = new TextView(this);
        title.setTextSize(16);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setText("\nОтчёт об ошибках");
        box.addView(title);

        Button refresh = new Button(this);
        refresh.setText("Обновить отчёт");
        refresh.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { refresh(); }
        });
        box.addView(refresh);

        Button copy = new Button(this);
        copy.setText("Скопировать отчёт");
        copy.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                cm.setPrimaryClip(ClipData.newPlainText("MouseMC report", fullReport()));
                Toast.makeText(MainActivity.this, "Скопировано. Вставь в чат.", Toast.LENGTH_SHORT).show();
            }
        });
        box.addView(copy);

        Button clear = new Button(this);
        clear.setText("Очистить отчёт");
        clear.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { Report.clear(MainActivity.this); refresh(); }
        });
        box.addView(clear);

        reportView = new TextView(this);
        reportView.setTextSize(11);
        reportView.setTypeface(Typeface.MONOSPACE);
        reportView.setTextIsSelectable(true);
        box.addView(reportView);

        ScrollView sv = new ScrollView(this);
        sv.addView(box);
        setContentView(sv);
        refresh();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
    }
}
